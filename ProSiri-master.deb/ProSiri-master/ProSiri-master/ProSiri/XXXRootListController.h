#import <Preferences/PSListController.h>

@interface XXXRootListController : PSListController

@end
